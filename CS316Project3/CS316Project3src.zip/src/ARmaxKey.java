public class ARmaxKey extends AR {
    int t;
    int returnVal;
    
    void maxKey() {
        returnVal = t;
    }
}
